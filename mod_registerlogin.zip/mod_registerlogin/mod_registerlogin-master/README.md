# Register Login Module for Joomla!
[![Github All Releases](https://img.shields.io/github/downloads/joomdev/mod_registerlogin/total.svg)](https://github.com/joomdev/mod_registerlogin/releases)
![AUR](https://img.shields.io/aur/license/yaourt.svg)
[![GitHub release](https://img.shields.io/github/release/joomdev/mod_registerlogin.svg)](https://github.com/joomdev/mod_registerlogin/releases)
